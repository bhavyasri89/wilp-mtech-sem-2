#!/bin/bash
if rm $1
then
	echo "$1 file deleted"
else
	echo "$1 file doesnot exist"
fi
