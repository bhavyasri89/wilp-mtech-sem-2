#!/bin/bash
for file in loop*.bak;
do
	rm $file 
	echo " file  removed"
done
