#!/bin/bash
echo "enter number"
read x
if test $x -ge 0
then
	echo "number is +ve"
else
	echo "number is -ve"
fi
