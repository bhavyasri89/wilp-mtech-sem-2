#!/bin/bash
echo "            MENU       
1. List\n 2. process\n 3. date\n 4.users\n 5.quit\n Enter the choice: \c "
read choice
case "$choice" in
	1) ls -l ;;
	2) ps -f ;;
	3) date ;;
	4) who ;;
	5) exit ;;
	*) echo "Invalid option"
esac
	
