#!/bin/bash
echo " input the number"
read n
if [ $n -le 0 ]
then
	echo " wrong arguments"
	exit 1;
fi
i=1
fact=1
while [ $i -le $n ]
#for((i=1;i<=n;i++))
do
	fact=`expr $i \* $fact`
	i=`expr $i + 1`
done
echo "factorial is $fact"	
