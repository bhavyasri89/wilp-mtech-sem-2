#!/bin/bash
while true;
do
	df 
	sleep 300
done &
