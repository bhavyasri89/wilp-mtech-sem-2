#!/bin/bash
echo "addition of two numbers"
#echo "enter first number:"
#read num1
#echo "enter second number:"
#read num2
c=$(($1 + $2))
echo $c

