#include<stdio.h>
#include<fcntl.h>
#include<unistd.h>
#include<sys/types.h>
#include<string.h>
#include<sys/stat.h>
int main()
{
    int fp1,fp2;
    char buf[200];
    fp1=open("foo.txt",O_WRONLY| O_CREAT);
    fp2=open("integernos.txt",O_RDONLY);
    strcpy(buf,"systemprogramming");
    write(fp1,buf,17);
    read(fp2,buf,100);
    printf("the read value is %s \n",buf);
    close(fp1);
    close(fp2);
    
}	
