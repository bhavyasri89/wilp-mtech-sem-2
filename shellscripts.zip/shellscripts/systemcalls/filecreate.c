#include<stdio.h>
#include<fcntl.h>
#include<unistd.h>
void main()
{
    int fd=creat("a.txt",O_WRONLY);
    printf("fd  = %d\n",fd);
}				

