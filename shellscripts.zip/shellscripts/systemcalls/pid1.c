#include<sys/types.h>
#include<stdio.h>
#include <unistd.h>
int main()
{
	pid_t pid;
	int p,p1;
	pid =fork();
	if (pid ==-1)
	{
		printf("enter in connection");
	}
	else if (pid ==0)
	{
		printf("\n child process1 :\n\n");
		p=getpid();
		printf("child process  id: %d\n",p);
		p1=getppid();
		printf("parent process id of child1: %d\n",p1);
	}
	else
	{
		printf("this is parent process \n");
		p=getpid();
		printf("parent: %d \n",p);		
		printf("process id of child: %d \n",pid);
	}
}
