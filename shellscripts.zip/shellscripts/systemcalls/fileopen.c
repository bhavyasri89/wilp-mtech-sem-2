#include<stdio.h>
#include<fcntl.h>
void main()
{
    int fd=open("foo.txt",O_WRONLY);
    printf("fd  = %d\n",fd);
    if (fd == -1)
    {
    	printf("file doesnot exist");
    }
}	
