#!/bin/bash
i=1;
for day in Mon Tue Wed Thu Fri Sat Sun;
do
	echo -n " DAY $((i++)) :$day "
	if [ $i -eq 7 -o $i -eq 8 ]
	then
		echo " -weekend"
	else
		echo " -weekday"
	fi
done

