

#!/bin/bash
echo "welcome"
echo "calculator"
ls -l




