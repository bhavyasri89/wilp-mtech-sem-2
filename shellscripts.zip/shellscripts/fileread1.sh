#!/bin/bash
echo "enter starting line number"
read startNum
echo "number of lines"
read numLine
endLine=$((startNum + numLine ))
head -5 file1.txt > datanew.txt

