#!/bin/bash

read -p "Enter the value of n: " n
sum=0
c=0
while [ $c -lt $n ]
do 
    read -p "Enter the number $c" input
    sum=$((sum + input))
    c=$((c+1))
done
echo "Sum is: " $sum
