#!/bin/bash
i=1
while [ $i -le 4 ]
do
	j=1
	while [ $j -le 4 ]
	do
	
		echo "$i $j"
		j=$(($j+1))
	done
	echo "" 	
	i=$(($i+1))
done
