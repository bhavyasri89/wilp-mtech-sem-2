#!/bin/bash
while read line
do
	flag=0;
	for((i=2;i<=line/2;i++))
	do
		j=`expr $line % $i`
		if [ $j -eq 0 ]
		then
			flag=1;
			break
		fi
	done
	if [ $flag -eq 0 ]
	then
		echo "$line" >> prime.txt
	fi
done < integernos.txt
