#!/bin/bash
echo "name: $0"
echo "arguments:$#"
echo "arg names: $*"
echo "pid: $$"
echo "pid2: $!"
