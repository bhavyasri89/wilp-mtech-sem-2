#!/bin/bash
if [ $1 -eq 0 ]
then
	echo " no zero tables"
	exit 1
fi
n=$1
i=1
while [ $i -le 10 ]
do
   echo " $i * $n= `expr $i \* $n`"
   i=`expr $i + 1`
done 
