#!/bin/bash
while true; do
df 
sleep 200
done &
