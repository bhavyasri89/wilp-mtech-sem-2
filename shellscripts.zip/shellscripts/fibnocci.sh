#!/bin/bash
echo " input the number:"
read n
fib0=0
fib1=1
fib2=1
if [ $n -le 0 ]
then
	echo "wrong arguements"
fi
for((i=0;i<=n;i++))
#i=0
#while [ $i -le $n ]
do
	echo "$fib0"
	fib0=$fib1
	fib1=$fib2
	fib2=`expr $fib0 + $fib1`
	#i=`expr $i + 1`
done
