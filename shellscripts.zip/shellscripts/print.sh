#!/bin/bash
i=1
while [ $i -le  4 ]  # Outer for loop
do
        j=1
        while [ $j -le  4 ]  # Inner for loop
        do
                echo  "$i , $j   "
                j=`expr $j + 1`
        done
        echo " "        #print the new line
        i=`expr $i + 1`
done
