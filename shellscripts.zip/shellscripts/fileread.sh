while read line
do
x=`expr $line % 2`
echo $x
echo $line
done < file1.txt
