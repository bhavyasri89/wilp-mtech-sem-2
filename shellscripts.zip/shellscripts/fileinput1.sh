#!/bin/bash
while read -r LINE
do 
x=`expr $LINE % 2`
if [ $x -eq 0 ]
then
echo "$LINE"
fi
done < integernos.txt
