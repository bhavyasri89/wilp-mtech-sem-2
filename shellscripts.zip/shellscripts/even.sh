#!/bin/bash
echo " enter the number :"
read n
i=`expr $n % 2`
if [ $i -eq 0 ]
then
	echo " number is even "
else
	echo " number is odd"
fi
