#include<stdio.h>
#include<sys/types.h>
#include<unistd.h>
int main()
{
pid_t p;
p=fork();
if(p==-1)
{
	printf("error in fork\n");
}
else if(p==0)
{
	printf("in child process\n");
}
else
{
	printf("in parent process\n");
}
}
