#!/bin/bash

echo " enter the department "
read  DEPARTMENT




case $DEPARTMENT in

  "Computer Science")
    echo -n " your department is Computer Science"
    ;;

   "Electrical and Electronics Engineering" | "Electrical Engineering")
    echo -n " your department is Electrical and Electronics Engineering or Electrical Engineering"
    ;;

  "Information Technology" | "Electronics and Communication")
    echo -n " your department is Information Technology or Electronics and Communication"
    ;;

  *)
  esac
