#!/bin/bash
echo "enter number1"
read x
echo "enter number2"
read y
echo "                  menu            
1. addition\n 2. Subtraction\n 3. Multiplication\n 4. Division\n 5.Modulo\n Enter your choice:\c"
read choice
case "$choice" in
	1) c= expr $x + $y
		 echo $c ;;
	2) c= expr $x - $y
		 echo $c ;;
	3) c= expr $x \* $y
		 echo $c ;;
	4) c= expr $x / $y
		 echo $c ;;
	5) c= expr $x % $y
		 echo $c ;;
	*) echo " invalid option"
esac
