#!/bin/bash
i=1;
while [ $i -le 5 ]
do
	echo " welcome $i times "
	i=`expr $i + 1`
done 
