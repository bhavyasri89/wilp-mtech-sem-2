#!/bin/bash
sum=0;
if [ $# -eq 0 ]
then
	echo "no arguments"
	exit 1;
fi
for i in $*
do
	sum=`expr $sum + $i`
done
echo " sum is : $sum"
