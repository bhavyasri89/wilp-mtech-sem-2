#!/bin/bash
#read -p "enter the range:" N
echo "enter the range"
read N
i=0
sum=0
while [ $i -lt $N ]
do 
	
	#sum=$((sum+i))
	sum=`expr $sum + $i`
	i=$(($i+1))
done
echo "$sum"
