#!/bin/bash
echo "enter the value of n:"
read n
sum=0
c=0;
while [ $c -le $n ]
do 
    sum=`expr $c + $sum`
    c=`expr $c + 1`
done
echo "Sum is: " $sum
