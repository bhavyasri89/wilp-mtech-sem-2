#!/bin/bash
while echo " enter the name :\c";
do
	read name
	if [ `expr "$name" : '.*'` -gt 20 ]; then
		
		echo "name is too long"
		exit;
	else
		echo $name
	fi
done
