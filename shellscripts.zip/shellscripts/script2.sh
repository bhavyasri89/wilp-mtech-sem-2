#!/bin/bash
echo $PATH
echo $SHELL
cal
date
pwd
