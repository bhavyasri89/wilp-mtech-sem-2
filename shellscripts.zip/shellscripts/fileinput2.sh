#!/bin/bash
i=1
while read  line
do
	j=`expr $i % 2`
	if [ $j -eq 0 ]
	then
		echo "$line" >> even.txt
	else
		echo "$line" >> odd.txt
	fi
i=`expr $i + 1`
done < integernos.txt
