#!/bin/bash
echo "enter the value"
read x
if [ $x -lt 10 ]
then
	echo " the value is less than 10"
elif [ $x -eq 10 ]
then
	echo " the value is  10"
elif [ $x -lt 100 ]
then
	echo " the number is greater than 10 and less than 100"
elif [ $x -eq 100 ]
then
	echo " the value is  100"
else 
	echo " the number is greater than 100"
fi

